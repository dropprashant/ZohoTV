//
//  NetworkManager.swift
//  ZTProject
//
//  Created by pras-zstch1465 on 19/12/24.
//

import Foundation

enum NetworkError: Error {
    case invalidURL
    case noData
}

class NetworkManager {
    
    static let shared = NetworkManager()
    
    private let baseURL = "https://testproject-60035326114.development.catalystserverless.in"
    private let projectID = "11608000000007080"
    
    func fetchData(completion: @escaping (Result<Data, Error>) -> Void) {
        let urlString = "\(baseURL)/baas/v1/project/\(projectID)"
        
        guard let url = URL(string: urlString) else {
            completion(.failure(NetworkError.invalidURL))
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let data = data else {
                completion(.failure(NetworkError.noData))
                return
            }
            
            completion(.success(data))
        }
        
        task.resume()
    }
    
    func fetchImage(from imageName: String, completion: @escaping (Result<Data, Error>) -> Void) {
            let imageURLString = "https://test-backet-development.zohostratus.in/\(imageName)"
            
            guard let url = URL(string: imageURLString) else {
                completion(.failure(NetworkError.invalidURL))
                return
            }
            
            let task = URLSession.shared.dataTask(with: url) { data, response, error in
                if let error = error {
                    completion(.failure(error))
                    return
                }
                
                guard let data = data else {
                    completion(.failure(NetworkError.noData))
                    return
                }
                
                completion(.success(data))
            }
            
            task.resume()
        }
}
