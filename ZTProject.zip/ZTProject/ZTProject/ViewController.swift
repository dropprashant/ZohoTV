//
//  ViewController.swift
//  ZTProject
//
//  Created by pras-zstch1465 on 19/12/24.
//

import UIKit
import SDWebImage

class ViewController: UIViewController {

    let imageView = UIImageView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupImageView()
        
        let imageName = "black-hole-wallpaper2.jpg"
        NetworkManager.shared.fetchImage(from: imageName) { result in
            switch result{
            case .success(let imageData):
                DispatchQueue.main.async {
                    self.imageView.image = UIImage(data: imageData)
                }
            case .failure(let error):
                print("Failed to fetch image: \(error)")
            }
        }
    }
    private func setupImageView(){
        imageView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(imageView)
        
        NSLayoutConstraint.activate([
            imageView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            imageView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            imageView.widthAnchor.constraint(equalToConstant: 200),
            imageView.heightAnchor.constraint(equalToConstant: 200)
        ])
        
        imageView.contentMode = .scaleAspectFit
    }

}

