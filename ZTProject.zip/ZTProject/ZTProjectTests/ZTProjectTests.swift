//
//  ZTProjectTests.swift
//  ZTProjectTests
//
//  Created by pras-zstch1465 on 19/12/24.
//

import Testing

struct ZTProjectTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
